#include<iostream>
using namespace std;

int main()
{
    double workHours, payRate, totalWages;
    
    cout<<"Enter hours worked: ";
    cin>>workHours;
    cout<<"Enter hourly rate: ";
    cin>>payRate;
    if(workHours>40.0)
        totalWages=40.0*payRate+1.5*payRate*(workHours-40.0);
    else
        totalWages=workHours*payRate;
    cout<<"Total wages: $"<<totalWages<<endl;
    return 0;
}