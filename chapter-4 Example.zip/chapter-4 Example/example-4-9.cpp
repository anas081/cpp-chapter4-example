#include<iostream>
using namespace std;

int main()
{
    int marks;
    
    cout<<"Enter your score: ";
    cin>>marks;
    if(marks>=60)
        cout<<"Passing"<<endl;
    cout<<"Failing"<<endl;
    return 0;
}