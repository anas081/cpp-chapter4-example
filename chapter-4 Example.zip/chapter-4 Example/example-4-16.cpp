#include<iostream>
using namespace std;

int main()
{
    double accountBalance, rateOfInterest;
    
    cout<<"Enter your account balance: ";
    cin>>accountBalance;
    if(accountBalance>50000.00)
        rateOfInterest=0.07;
    else
    {
        if(accountBalance>=25000.00)
            rateOfInterest=0.05;
        else
        {
            if(accountBalance>=1000.00)
                rateOfInterest=0.03;
            else
                rateOfInterest=0.00;
        }
    }
    cout<<"Interest Rate: "<<rateOfInterest*100<<"%"<<endl;
    return 0;
}