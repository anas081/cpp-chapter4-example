#include<iostream>
using namespace std;

int main()
{
    cout<<"(14 >= 5) || ('A' > 'B') = "<<((14>=5)||('A'>'B'))<<endl;
    cout<<"(24 >= 35) || ('A' > 'B') = "<<((24>=35)||('A'>'B'))<<endl;
    cout<<"('A' <= 'a') || (7 != 7) = "<<(('A'<='a')||(7!=7))<<endl;
    return 0;
}