#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
    double luggageSize, luggageWeight, extraCharges;
    extraCharges=0.0;
    
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Line 10: Enter suitcase dimensions "<<"(length + width + depth) in inches: ";
    cin>>luggageSize;
    cout<<endl;
    cout<<"Line 13: Enter suitcase weight in pounds: ";
    cin>>luggageWeight;
    cout<<endl;
    if(luggageSize>108||luggageWeight>50)
        extraCharges=50.00;
    cout<<"Line 18: Additional suitcase charges: $"<<extraCharges<<endl;
    return 0;
}