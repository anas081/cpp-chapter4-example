#include<iostream>
using namespace std;

int main()
{
    int testMarks;
    char letterGrade;
    
    cout<<"Enter the score (0-100): ";
    cin>>testMarks;
    switch(testMarks/10)
    {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            letterGrade='F';
            break;
        case 6:
            letterGrade='D';
            break;
        case 7:
            letterGrade='C';
            break;
        case 8:
            letterGrade='B';
            break;
        case 9:
        case 10:
            letterGrade='A';
            break;
        default:
            cout<<"Invalid test score."<<endl;
            return 1;
    }
    cout<<"The grade is: "<<letterGrade<<endl;
    return 0;
}