#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
    double salary, hourlyRate, totalHours;
    
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Line 8: Enter working hours and rate: ";
    cin>>totalHours>>hourlyRate;
    if(totalHours>40.0)
        salary=40.0*hourlyRate+1.5*hourlyRate*(totalHours-40.0);
    else
        salary=totalHours*hourlyRate;
    cout<<endl;
    cout<<"Line 15: The wages are $"<<salary<<endl;
    return 0;
}