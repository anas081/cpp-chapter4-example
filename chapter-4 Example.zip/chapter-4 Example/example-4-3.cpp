#include<iostream>
#include<iomanip>
using namespace std;
const double INTEREST_RATE=0.015;

int main()
{
    double cardBalance, amountPaid, remainingBalance, penaltyAmount;
    penaltyAmount=0.0;
    
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Line 12: Enter credit card balance: ";
    cin>>cardBalance;
    cout<<endl;
    cout<<"Line 15: Enter the payment: ";
    cin>>amountPaid;
    cout<<endl;
    remainingBalance=cardBalance-amountPaid;
    if(remainingBalance>0)
        penaltyAmount=remainingBalance*INTEREST_RATE;
    cout<<"Line 21: The balance is: $"<<remainingBalance<<endl;
    cout<<"Line 22: The penalty to be added to your "<<"next month bill is: $"<<penaltyAmount<<endl;
    return 0;
}