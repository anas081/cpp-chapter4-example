#include<iostream>
using namespace std;

int main()
{
    int temp;
    
    cout<<"Enter the temperature: ";
    cin>>temp;
    if(temp>=50)
    {
        if(temp>=80)
            cout<<"Good day for swimming."<<endl;
        else
            cout<<"Good day for golfing."<<endl;
    }
    else
    {
        cout<<"Good day to play tennis."<<endl;
    }
    return 0;
}