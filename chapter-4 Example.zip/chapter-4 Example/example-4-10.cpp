#include<iostream>
using namespace std;

int main()
{
    cout<<"!('A' > 'B') = "<<(!('A'>'B'))<<endl;
    cout<<"!(6 <= 7) = "<<(!(6<=7))<<endl;
    return 0;
}