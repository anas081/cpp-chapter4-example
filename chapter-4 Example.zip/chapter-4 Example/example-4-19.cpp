#include<iostream>
using namespace std;

int main()
{
    int temp;
    temp=75;
    
    if(temp>=70)
        if(temp>=80)
            cout<<"Good day for swimming."<<endl;
        else
            cout<<"Good day for golfing."<<endl;
    return 0;
}