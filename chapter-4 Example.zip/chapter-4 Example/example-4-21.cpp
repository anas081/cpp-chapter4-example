#include<iostream>
using namespace std;

int main()
{
    int personAge, numX;
    char letterGrade;
    personAge=25;
    letterGrade='B';
    numX=10;
    
    if((personAge>=21)||(numX==5))
    {
        cout<<"Line 1: The condition is true."<<endl;
    }
    else
    {
        cout<<"Line 1: The condition is false."<<endl;
    }
    if((letterGrade=='A')&&(numX>=7))
    {
        cout<<"Line 2: The condition is true."<<endl;
    }
    else
    {
        cout<<"Line 2: The condition is false."<<endl;
    }
    return 0;
}