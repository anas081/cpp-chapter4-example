#include<iostream>
using namespace std;

int main()
{
    bool isFound;
    int personAge, totalCount;
    double workHours, extraTime;
    char letter;
    isFound=true;
    personAge=20;
    workHours=45.30;
    extraTime=15.00;
    totalCount=20;
    letter='B';
    
    cout<<boolalpha;
    cout<<"!isFound = "<<(!isFound)<<endl;
    cout<<"workHours > 40.00 = "<<(workHours>40.00)<<endl;
    cout<<"!personAge = "<<(!personAge)<<endl;
    cout<<"!isFound && (personAge >= 18) = "<<(!isFound&&(personAge>=18))<<endl;
    cout<<"!(isFound && (personAge >= 18)) = "<<(!(isFound&&(personAge>=18)))<<endl;
    cout<<"workHours + extraTime <= 75.00 = "<<(workHours+extraTime<=75.00)<<endl;
    cout<<"(totalCount >= 0) && (totalCount <= 100) = "<<((totalCount>=0)&&(totalCount<=100))<<endl;
    cout<<"('A' <= letter && letter <= 'Z') = "<<(('A'<=letter&&letter<='Z'))<<endl;
    cout<<endl;
    cout<<"11 > 5 || 6 < 15 && 7 >= 8 = "<<(11>5||6<15&&7>=8)<<endl;
    cout<<"11 > 5 || (6 < 15 && 7 >= 8) = "<<(11>5||(6<15&&7>=8))<<endl;
    return 0;
}