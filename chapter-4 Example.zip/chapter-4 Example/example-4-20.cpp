#include<iostream>
using namespace std;

int main()
{
    char personGender;
    int personAge;
    double insuranceRate;
    personGender='M';
    personAge=25;
    
    if(personGender=='M')
        if(personAge<21)
            insuranceRate=0.05;
        else
            insuranceRate=0.35;
    else if(personGender=='F')
        if(personAge<21)
            insuranceRate=0.04;
        else
            insuranceRate=0.30;
    cout<<"Policy rate: "<<insuranceRate<<endl;
    return 0;
}