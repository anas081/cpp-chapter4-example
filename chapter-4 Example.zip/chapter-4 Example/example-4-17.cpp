#include<iostream>
using namespace std;

int main()
{
    int marks;
    
    cout<<"Enter the score: ";
    cin>>marks;
    if(marks>=90)
        cout<<"The grade is A."<<endl;
    else if(marks>=80)
        cout<<"The grade is B."<<endl;
    else if(marks>=70)
        cout<<"The grade is C."<<endl;
    else if(marks>=60)
        cout<<"The grade is D."<<endl;
    else
        cout<<"The grade is F."<<endl;
    return 0;
}