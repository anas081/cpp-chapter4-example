#include<iostream>
using namespace std;

int main()
{
    int marks;
    char result;
    result='F';
    
    cout<<"Enter your score: ";
    cin>>marks;
    if(marks>=60)
        result='P';
    cout<<"Your grade is: "<<result<<endl;
    return 0;
}